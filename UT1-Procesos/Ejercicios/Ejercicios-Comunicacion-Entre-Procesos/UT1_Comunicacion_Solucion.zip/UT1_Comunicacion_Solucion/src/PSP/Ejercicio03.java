package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio03 {
    public static void main(String[] args) throws IOException, InterruptedException {
        int hora;
        if (args.length > 0) {
            hora = Integer.parseInt(args[0]);   // para probar otras horas
        } else {
            // date +%H devuelve la hora actual (00-23)
            Process p = new ProcessBuilder("date", "+%H").start();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String texto = br.readLine().trim();
            br.close();
            p.waitFor();
            hora = Integer.parseInt(texto);
        }

        System.out.println("Son las " + hora + " horas");
        if (hora >= 6 && hora < 14) {
            System.out.println("Buenos días");
        } else if (hora >= 14 && hora < 21) {
            System.out.println("Buenas tardes");
        } else {
            System.out.println("Buenas noches");
        }
    }
}
