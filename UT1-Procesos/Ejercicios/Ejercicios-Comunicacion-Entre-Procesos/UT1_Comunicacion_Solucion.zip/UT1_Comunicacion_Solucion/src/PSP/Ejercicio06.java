package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio06 {
    public static void main(String[] args) throws InterruptedException {
        String[][] comandos = {
            {"date"},
            {"ls", "carpetaQueNoExiste"},
            {"comandoInventado"},
            {"cat", "ficheroQueNoExiste.txt"},
            {"whoami"}
        };

        int correctos = 0;
        for (int i = 0; i < comandos.length; i++) {
            ProcessBuilder pb = new ProcessBuilder(comandos[i]);
            pb.redirectErrorStream(true);   // errores y salida por el mismo flujo
            String nombre = String.join(" ", comandos[i]);

            try {
                Process p = pb.start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String primera = br.readLine();
                while (br.readLine() != null) {
                    // consumimos el resto de la salida
                }
                br.close();
                int codigo = p.waitFor();

                if (codigo == 0) {
                    System.out.println("[OK]        " + nombre);
                    correctos++;
                } else {
                    System.out.println("[FALLO " + codigo + "]   " + nombre + " -> " + primera);
                }
            } catch (IOException e) {
                System.out.println("[NO EXISTE] " + nombre);
            }
        }
        System.out.println("\nCorrectos: " + correctos + " de " + comandos.length);
    }
}
