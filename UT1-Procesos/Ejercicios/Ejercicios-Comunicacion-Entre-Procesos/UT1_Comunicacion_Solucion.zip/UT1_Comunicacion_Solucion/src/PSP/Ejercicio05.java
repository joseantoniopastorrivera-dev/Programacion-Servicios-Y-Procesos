package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio05 {
    public static void main(String[] args) throws IOException, InterruptedException {
        if (args.length < 2) {
            System.out.println("Uso: java -cp bin PSP.Ejercicio05 <palabra> <fichero>");
            return;
        }
        String palabra = args[0];
        String fichero = args[1];

        Process p = new ProcessBuilder("grep", "-n", palabra, fichero).start();

        // Salida: líneas del tipo "3:texto de la línea"
        BufferedReader salida = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea;
        int encontradas = 0;
        while ((linea = salida.readLine()) != null) {
            int dosPuntos = linea.indexOf(':');
            String numero = linea.substring(0, dosPuntos);
            String texto = linea.substring(dosPuntos + 1);
            System.out.println("Línea " + numero + ": " + texto);
            encontradas++;
        }

        // Errores (por ejemplo, si el fichero no existe)
        BufferedReader errores = new BufferedReader(new InputStreamReader(p.getErrorStream()));
        String error = errores.readLine();

        int codigo = p.waitFor();
        if (codigo == 0) {
            System.out.println("\"" + palabra + "\" aparece en " + encontradas + " líneas");
        } else if (codigo == 1) {
            System.out.println("\"" + palabra + "\" no aparece en " + fichero);
        } else {
            System.out.println("Error de grep (código " + codigo + "): " + error);
        }
    }
}
