package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio01 {
    public static void main(String[] args) throws IOException, InterruptedException {
        Process p = new ProcessBuilder("echo", "Hola desde el hijo").start();

        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea;
        while ((linea = br.readLine()) != null) {
            System.out.println("[HIJO] " + linea);
        }
        br.close();

        System.out.println("Código de salida: " + p.waitFor());
    }
}
