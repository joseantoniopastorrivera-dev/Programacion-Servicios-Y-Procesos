package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Scanner;

public class Ejercicio09 {
    public static void main(String[] args) throws IOException, InterruptedException {
        Process hijo = new ProcessBuilder("java", "-cp", "bin", "PSP.HijoInverso").start();
        PrintWriter haciaHijo = new PrintWriter(hijo.getOutputStream());
        BufferedReader desdeHijo = new BufferedReader(new InputStreamReader(hijo.getInputStream()));

        Scanner sc = new Scanner(System.in);
        System.out.println("Escribe frases (\"salir\" para terminar):");
        String frase = sc.nextLine();
        while (!frase.equals("salir")) {
            haciaHijo.println(frase);
            haciaHijo.flush();   // la enviamos ya, sin cerrar

            String invertida = desdeHijo.readLine();
            System.out.println("Hijo: " + invertida);
            if (frase.replace(" ", "").equalsIgnoreCase(invertida.replace(" ", ""))) {
                System.out.println("  ¡Es un palíndromo!");
            }
            frase = sc.nextLine();
        }

        haciaHijo.close();
        System.out.println("El hijo terminó con código " + hijo.waitFor());
        sc.close();
    }
}
