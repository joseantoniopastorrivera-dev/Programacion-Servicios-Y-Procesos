package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class Ejercicio10 {
    public static void main(String[] args) throws IOException, InterruptedException {
        String[] operaciones = {"3 + 4", "10 / 4", "6 * 7", "8 / 0", "hola + 2", "5 ^ 2", "20 - 25"};

        Process hijo = new ProcessBuilder("java", "-cp", "bin", "PSP.HijoCalculadora").start();
        PrintWriter haciaHijo = new PrintWriter(hijo.getOutputStream());
        BufferedReader desdeHijo = new BufferedReader(new InputStreamReader(hijo.getInputStream()));

        int errores = 0;
        for (int i = 0; i < operaciones.length; i++) {
            haciaHijo.println(operaciones[i]);
            haciaHijo.flush();
            String respuesta = desdeHijo.readLine();
            if (respuesta.equals("ERROR")) {
                errores++;
                System.out.println(operaciones[i] + "  ->  operación no válida");
            } else {
                System.out.println(operaciones[i] + "  =  " + respuesta);
            }
        }

        haciaHijo.println("fin");
        haciaHijo.close();
        System.out.println("\nOperaciones no válidas: " + errores);
        System.out.println("El hijo terminó con código " + hijo.waitFor());
    }
}
