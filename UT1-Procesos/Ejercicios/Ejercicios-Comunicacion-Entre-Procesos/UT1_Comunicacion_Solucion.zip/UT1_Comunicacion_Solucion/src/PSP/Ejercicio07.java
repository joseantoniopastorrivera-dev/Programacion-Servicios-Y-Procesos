package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Scanner;

public class Ejercicio07 {
    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Expresión: ");
        String expresion = sc.nextLine();

        Process p = new ProcessBuilder("bc", "-l").start();   // -l: decimales y funciones matemáticas

        PrintWriter pw = new PrintWriter(p.getOutputStream());
        pw.println(expresion);
        pw.close();   // sin esto, bc sigue esperando más expresiones

        BufferedReader salida = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String resultado = salida.readLine();   // null si bc no ha escrito nada en su salida
        salida.close();

        BufferedReader errores = new BufferedReader(new InputStreamReader(p.getErrorStream()));
        String error = errores.readLine();
        while (error != null && error.isEmpty()) {   // bc empieza con una línea en blanco
            error = errores.readLine();
        }
        errores.close();

        int codigo = p.waitFor();
        if (resultado != null && codigo == 0) {
            System.out.println(expresion + " = " + resultado);
        } else {
            System.out.println("bc no puede calcular \"" + expresion + "\": " + error + " (código " + codigo + ")");
        }
        sc.close();
    }
}
