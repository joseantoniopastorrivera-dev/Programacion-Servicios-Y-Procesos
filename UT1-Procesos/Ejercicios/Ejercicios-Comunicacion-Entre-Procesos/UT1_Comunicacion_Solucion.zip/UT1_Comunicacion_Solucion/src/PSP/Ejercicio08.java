package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Scanner;

public class Ejercicio08 {
    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Texto: ");
        String texto = sc.nextLine();

        String cifrado = rot13(texto);
        System.out.println("Cifrado:   " + cifrado);

        // La salida del primer tr es la entrada del segundo
        String descifrado = rot13(cifrado);
        System.out.println("Descifrado: " + descifrado);

        System.out.println("¿Coincide con el original?: " + descifrado.equals(texto));
        sc.close();
    }

    // Envía el texto a tr y devuelve lo que responde
    private static String rot13(String texto) throws IOException, InterruptedException {
        Process p = new ProcessBuilder("tr", "A-Za-z", "N-ZA-Mn-za-m").start();

        PrintWriter pw = new PrintWriter(p.getOutputStream());
        pw.println(texto);
        pw.close();

        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String resultado = br.readLine();
        br.close();
        p.waitFor();
        return resultado;
    }
}
