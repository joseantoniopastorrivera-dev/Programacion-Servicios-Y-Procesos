package PSP;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Ejercicio13 {
    public static void main(String[] args) throws IOException, InterruptedException {
        File texto = new File("datos/texto.txt");

        // Parte básica: tr -cs 'A-Za-z' '\n' < texto.txt | sort -u | wc -l
        ProcessBuilder tr = new ProcessBuilder("tr", "-cs", "A-Za-z", "\n");
        tr.redirectInput(texto);

        List<ProcessBuilder> tuberia = new ArrayList<ProcessBuilder>();
        tuberia.add(tr);
        tuberia.add(new ProcessBuilder("sort", "-u"));
        tuberia.add(new ProcessBuilder("wc", "-l"));

        List<Process> procesos = ProcessBuilder.startPipeline(tuberia);
        String distintas = leerTodo(procesos.get(procesos.size() - 1)).trim();
        esperarTodos(procesos);
        System.out.println("Palabras distintas: " + distintas);

        // Ampliación: tr ... < texto.txt | tr 'A-Z' 'a-z' | sort | uniq -c | sort -rn | head -5
        ProcessBuilder tr2 = new ProcessBuilder("tr", "-cs", "A-Za-z", "\n");
        tr2.redirectInput(texto);

        List<ProcessBuilder> tuberia2 = new ArrayList<ProcessBuilder>();
        tuberia2.add(tr2);
        tuberia2.add(new ProcessBuilder("tr", "A-Z", "a-z"));
        tuberia2.add(new ProcessBuilder("sort"));
        tuberia2.add(new ProcessBuilder("uniq", "-c"));
        tuberia2.add(new ProcessBuilder("sort", "-rn"));
        tuberia2.add(new ProcessBuilder("head", "-5"));

        List<Process> procesos2 = ProcessBuilder.startPipeline(tuberia2);
        System.out.println("\nLas 5 palabras más frecuentes:");
        System.out.print(leerTodo(procesos2.get(procesos2.size() - 1)));
        esperarTodos(procesos2);
    }

    private static String leerTodo(Process p) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String linea;
        while ((linea = br.readLine()) != null) {
            sb.append(linea).append("\n");
        }
        br.close();
        return sb.toString();
    }

    private static void esperarTodos(List<Process> procesos) throws InterruptedException {
        for (int i = 0; i < procesos.size(); i++) {
            procesos.get(i).waitFor();
        }
    }
}
