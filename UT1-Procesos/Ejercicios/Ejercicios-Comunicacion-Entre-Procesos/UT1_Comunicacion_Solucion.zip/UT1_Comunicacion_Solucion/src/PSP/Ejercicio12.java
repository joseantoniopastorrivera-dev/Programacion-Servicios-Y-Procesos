package PSP;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;

public class Ejercicio12 {
    public static void main(String[] args) throws IOException, InterruptedException {
        File diario = new File("diario.log");

        // 1) Cabecera con la fecha: date admite un formato propio
        ProcessBuilder fecha = new ProcessBuilder("date", "+=== %d/%m/%Y %H:%M:%S ===");
        fecha.redirectOutput(Redirect.appendTo(diario));
        fecha.start().waitFor();

        // 2) Contenido de la carpeta actual
        ProcessBuilder ls = new ProcessBuilder("ls", "-l");
        ls.redirectOutput(Redirect.appendTo(diario));
        ls.start().waitFor();

        // 3) Contamos las entradas del diario (líneas que empiezan por ===)
        BufferedReader br = new BufferedReader(new FileReader(diario));
        int entradas = 0;
        String ultima = "";
        String linea;
        while ((linea = br.readLine()) != null) {
            if (linea.startsWith("===")) {
                entradas++;
                ultima = linea;
            }
        }
        br.close();

        System.out.println("Entrada añadida: " + ultima);
        System.out.println("El diario tiene " + entradas + " entradas (" + diario.length() + " bytes)");
    }
}
