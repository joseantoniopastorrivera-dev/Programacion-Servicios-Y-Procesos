package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio02 {
    public static void main(String[] args) throws IOException, InterruptedException {
        String usuario = ejecutar("whoami");
        String equipo = ejecutar("hostname");
        System.out.println("Usuario " + usuario + " en el equipo " + equipo);
    }

    // Lanza un comando y devuelve la primera línea de su salida
    private static String ejecutar(String comando) throws IOException, InterruptedException {
        Process p = new ProcessBuilder(comando).start();
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea = br.readLine();
        br.close();
        p.waitFor();
        return linea;
    }
}
