package PSP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio04 {
    public static void main(String[] args) throws IOException, InterruptedException {
        String carpeta = "/usr/bin";
        if (args.length > 0) {
            carpeta = args[0];
        }

        // ls -S ordena por tamaño, de mayor a menor
        Process p = new ProcessBuilder("ls", "-S", carpeta).start();
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

        System.out.println("Los 5 ficheros más grandes de " + carpeta + ":");
        int leidas = 0;
        String linea;
        while (leidas < 5 && (linea = br.readLine()) != null) {
            leidas++;
            System.out.println(leidas + ". " + linea);
        }

        // Ya no nos interesa el resto: si el hijo sigue vivo, lo terminamos
        if (p.isAlive()) {
            System.out.println("(el hijo sigue vivo, lo terminamos)");
            p.destroy();
        }
        br.close();
        System.out.println("Código de salida: " + p.waitFor());
    }
}
