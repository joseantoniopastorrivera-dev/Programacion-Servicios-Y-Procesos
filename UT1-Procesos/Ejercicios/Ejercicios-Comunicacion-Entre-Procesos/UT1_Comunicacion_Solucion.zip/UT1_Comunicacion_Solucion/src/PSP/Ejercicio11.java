package PSP;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Ejercicio11 {
    public static void main(String[] args) throws IOException, InterruptedException {
        File entrada = new File("datos/notas.csv");
        File salida = new File("datos/notas_ordenadas.csv");

        // sort -t, -k2 -rn < notas.csv > notas_ordenadas.csv
        //   -t,  : el separador de campos es la coma
        //   -k2  : ordenar por el segundo campo (la nota)
        //   -rn  : orden numérico, de mayor a menor
        ProcessBuilder pb = new ProcessBuilder("sort", "-t,", "-k2", "-rn");
        pb.redirectInput(entrada);
        pb.redirectOutput(salida);
        int codigo = pb.start().waitFor();
        System.out.println("sort terminado con código " + codigo);

        // Leemos el fichero generado y mostramos el podio
        BufferedReader br = new BufferedReader(new FileReader(salida));
        String[] medallas = {"Oro", "Plata", "Bronce"};
        String linea;
        int puesto = 0;
        while ((linea = br.readLine()) != null && puesto < 3) {
            String[] campos = linea.split(",");
            System.out.println(medallas[puesto] + ": " + campos[0] + " (" + campos[1] + ")");
            puesto++;
        }
        br.close();
        System.out.println("Clasificación completa en " + salida.getPath());
    }
}
